'use strict';
const express = require('express');
const router  = express.Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const crypto  = require('crypto');
const { db }  = require('../db');

// ─── CONSTANTS ────────────────────────────────────────────────────────────────
const JWT_SECRET         = process.env.JWT_SECRET         || 'fp_jwt_dev_secret_change_in_production_2026';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'fp_refresh_dev_secret_change_in_production_2026';
const IS_PROD            = process.env.NODE_ENV === 'production';
const BCRYPT_ROUNDS      = IS_PROD ? 12 : 10;
const ACCESS_TTL         = '15m';
const REFRESH_TTL        = '7d';
const REFRESH_TTL_MS     = 7 * 24 * 60 * 60 * 1000;
const OTP_TTL_MS         = 15 * 60 * 1000;
const COOKIE_BASE        = { httpOnly: true, secure: IS_PROD, sameSite: IS_PROD ? 'strict' : 'lax' };

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function makeTokens(user) {
  const payload = { sub: user.id, email: user.email, plan: user.plan, role: user.role };
  return {
    access:  jwt.sign(payload, JWT_SECRET,         { expiresIn: ACCESS_TTL }),
    refresh: jwt.sign({ sub: user.id }, JWT_REFRESH_SECRET, { expiresIn: REFRESH_TTL })
  };
}

function setCookies(res, access, refresh) {
  res.cookie('access_token',  access,  { ...COOKIE_BASE, maxAge: 15 * 60 * 1000 });
  res.cookie('refresh_token', refresh, { ...COOKIE_BASE, maxAge: REFRESH_TTL_MS, path: '/api/auth' });
}

function clearCookies(res) {
  res.clearCookie('access_token');
  res.clearCookie('refresh_token', { path: '/api/auth' });
}

// Strip ALL sensitive fields before sending user to client
function safeUser(u) {
  if (!u) return null;
  const { password_hash, mfa_secret, failed_attempts, locked_until, otp_hash, ...safe } = u;
  return safe;
}

function isValidEmail(e) {
  return typeof e === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.trim());
}

function getToken(req) {
  return (req.cookies && req.cookies.access_token) ||
         (req.headers.authorization || '').replace('Bearer ', '').trim() || null;
}

function audit(userId, action, ip, success, detail) {
  try {
    db.get('audit_log').push({
      id: uuidv4(), user_id: userId || null, action,
      ip: ip || null, success: !!success,
      detail: detail ? String(detail).substring(0, 200) : null,
      created_at: new Date().toISOString()
    }).write();
  } catch (_) {}
}

function consentLog(userId, action, detail, ip, ua) {
  try {
    db.get('consent_log').push({
      id: uuidv4(), user_id: userId, action,
      details: detail || null, ip_address: ip || null,
      user_agent: ua ? ua.substring(0, 300) : null,
      created_at: new Date().toISOString()
    }).write();
  } catch (_) {}
}

// ─── POST /api/auth/register ──────────────────────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const { first_name, last_name, password, rgpd_consent, marketing_consent } = req.body;
    const email = (req.body.email || '').toLowerCase().trim();
    const plan  = ['starter', 'pro', 'business'].includes(req.body.plan) ? req.body.plan : 'starter';
    const ip = req.ip || '127.0.0.1';
    const ua = req.headers['user-agent'] || '';

    // ── Validation ────────────────────────────────────────────────────────────
    if (!email || !password || !first_name || !last_name)
      return res.status(400).json({ error: 'Tous les champs sont obligatoires.' });

    if (!isValidEmail(email))
      return res.status(400).json({ error: 'Adresse e-mail invalide.' });

    if (!rgpd_consent)
      return res.status(400).json({ error: 'Le consentement RGPD est obligatoire.' });

    if (typeof password !== 'string' || password.length < 8)
      return res.status(400).json({ error: 'Mot de passe : 8 caractères minimum.' });

    // ── Unicité email (409 si doublon) ────────────────────────────────────────
    const existing = db.get('users').find(u =>
      u.email === email && u.is_active !== false && !u.deleted_at
    ).value();
    if (existing)
      return res.status(409).json({ error: 'Un compte existe déjà avec cet e-mail.' });

    // ── Création ──────────────────────────────────────────────────────────────
    const hash    = await bcrypt.hash(password, BCRYPT_ROUNDS);
    const now     = new Date().toISOString();
    const userId  = uuidv4();
    const initials = (first_name[0] + last_name[0]).toUpperCase();

    const newUser = {
      id: userId, email, password_hash: hash,
      first_name: first_name.trim(), last_name: last_name.trim(),
      avatar_initials: initials, phone: '', siret: '', tva_number: '',
      tva_exempt: true, address: '', city: '', postal_code: '', country: 'FR',
      plan, role: 'formateur', oauth_provider: null,
      email_verified: false, is_active: true, deleted_at: null,
      rgpd_consent: true, rgpd_consent_date: now, rgpd_consent_ip: ip,
      marketing_consent: !!marketing_consent,
      failed_attempts: 0, locked_until: null,
      last_login: now, login_count: 1,
      created_at: now, updated_at: now
    };

    db.get('users').push(newUser).write();

    // Default settings
    db.get('settings').push({
      user_id: userId, invoice_prefix: 'FP', default_payment_terms: 30,
      bank_iban: '', bank_bic: '',
      notif_invoice_reminder: true, notif_session_reminder: true, notif_email: true,
      created_at: now, updated_at: now
    }).write();

    consentLog(userId, 'REGISTER_CONSENT', 'CGU v1.0 + Politique confidentialite v1.0', ip, ua);
    audit(userId, 'REGISTER', ip, true, email);

    const { access, refresh } = makeTokens(newUser);
    setCookies(res, access, refresh);

    res.status(201).json({
      message: 'Compte créé avec succès',
      access_token: access,
      user: safeUser(newUser)
    });
  } catch (err) {
    console.error('[REGISTER]', err);
    res.status(500).json({ error: 'Erreur serveur. Réessayez.' });
  }
});

// ─── POST /api/auth/login ─────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { password } = req.body;
    const email = (req.body.email || '').toLowerCase().trim();
    const ip    = req.ip || '127.0.0.1';
    const ua    = req.headers['user-agent'] || '';

    if (!email || !password)
      return res.status(400).json({ error: 'E-mail et mot de passe requis.' });

    // Lookup user — must have password_hash (not OAuth-only) and not deleted
    const user = db.get('users').find(u => u.email === email).value();

    if (!user || !user.password_hash || user.deleted_at) {
      audit(null, 'LOGIN_FAIL', ip, false, `unknown: ${email}`);
      return res.status(401).json({ error: 'Identifiants incorrects.' });
    }

    if (!user.is_active) {
      return res.status(403).json({ error: 'Compte désactivé. Contactez le support.' });
    }

    // Lockout check
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      const until = new Date(user.locked_until).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
      return res.status(423).json({ error: `Compte verrouillé jusqu'à ${until}. Trop de tentatives.` });
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      const attempts   = (user.failed_attempts || 0) + 1;
      const lockUntil  = attempts >= 5 ? new Date(Date.now() + 30 * 60 * 1000).toISOString() : null;
      db.get('users').find({ id: user.id }).assign({
        failed_attempts: attempts,
        locked_until:    lockUntil,
        updated_at:      new Date().toISOString()
      }).write();
      audit(user.id, 'LOGIN_FAIL', ip, false, `attempt ${attempts}`);
      if (lockUntil) return res.status(423).json({ error: 'Trop de tentatives. Compte verrouillé 30 minutes.' });
      return res.status(401).json({ error: 'Identifiants incorrects.' });
    }

    // Success — reset lockout
    const now = new Date().toISOString();
    db.get('users').find({ id: user.id }).assign({
      failed_attempts: 0, locked_until: null,
      last_login: now, login_count: (user.login_count || 0) + 1,
      updated_at: now
    }).write();
    audit(user.id, 'LOGIN_OK', ip, true);

    const fresh = db.get('users').find({ id: user.id }).value();
    const { access, refresh } = makeTokens(fresh);
    setCookies(res, access, refresh);

    res.json({ message: 'Connexion réussie', access_token: access, user: safeUser(fresh) });
  } catch (err) {
    console.error('[LOGIN]', err);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

// ─── GET /api/auth/me ─────────────────────────────────────────────────────────
router.get('/me', (req, res) => {
  // Bearer token only — no cookie fallback here (explicit auth check)
  const token = (req.headers.authorization || '').replace('Bearer ', '').trim() ||
                (req.cookies && req.cookies.access_token) || null;

  if (!token) return res.status(401).json({ error: 'Non authentifié.' });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user    = db.get('users').find(u => u.id === decoded.sub && u.is_active && !u.deleted_at).value();
    if (!user)    return res.status(401).json({ error: 'Utilisateur introuvable.' });
    res.json({ user: safeUser(user) });
  } catch (e) {
    if (e.name === 'TokenExpiredError') return res.status(401).json({ error: 'TOKEN_EXPIRED' });
    res.status(401).json({ error: 'Token invalide.' });
  }
});

// ─── POST /api/auth/refresh ───────────────────────────────────────────────────
router.post('/refresh', (req, res) => {
  const token = (req.cookies && req.cookies.refresh_token) || null;
  if (!token) return res.status(401).json({ error: 'Session expirée. Reconnectez-vous.' });
  try {
    const decoded = jwt.verify(token, JWT_REFRESH_SECRET);
    const user    = db.get('users').find(u => u.id === decoded.sub && u.is_active && !u.deleted_at).value();
    if (!user)    return res.status(401).json({ error: 'Utilisateur introuvable.' });

    const { access, refresh } = makeTokens(user);
    setCookies(res, access, refresh);
    res.json({ message: 'Token rafraîchi', access_token: access, user: safeUser(user) });
  } catch (e) {
    clearCookies(res);
    res.status(401).json({ error: 'SESSION_EXPIRED' });
  }
});

// ─── POST /api/auth/logout ────────────────────────────────────────────────────
router.post('/logout', (req, res) => {
  clearCookies(res);
  res.json({ message: 'Déconnecté avec succès.' });
});

// ─── POST /api/auth/forgot-password ──────────────────────────────────────────
router.post('/forgot-password', async (req, res) => {
  const email = (req.body.email || '').toLowerCase().trim();
  const ip    = req.ip || '127.0.0.1';

  if (!email) return res.status(400).json({ error: 'E-mail requis.' });

  // Always same response (anti-enumeration RGPD)
  res.json({ message: `Si ce compte existe, un code a été envoyé à ${email}.` });

  // Async side-effect
  setImmediate(async () => {
    try {
      const user = db.get('users').find(u => u.email === email && u.is_active && !u.deleted_at).value();
      if (!user) return;
      const otp     = Math.floor(100000 + Math.random() * 900000).toString();
      const otpHash = await bcrypt.hash(otp, 8);
      db.get('password_resets').remove({ user_id: user.id }).write();
      db.get('password_resets').push({
        id: uuidv4(), user_id: user.id, otp_hash: otpHash,
        expires_at: new Date(Date.now() + OTP_TTL_MS).toISOString(),
        used: false, ip, created_at: new Date().toISOString()
      }).write();
      audit(user.id, 'FORGOT_PW', ip, true);
      console.log(`\n  📧 OTP DEMO → ${otp} (pour ${email}) — valide 15 min\n`);
    } catch (e) { console.error('[FORGOT-PW]', e.message); }
  });
});

// ─── POST /api/auth/verify-otp ───────────────────────────────────────────────
router.post('/verify-otp', async (req, res) => {
  const { otp } = req.body;
  const email   = (req.body.email || '').toLowerCase().trim();

  if (!email || !otp) return res.status(400).json({ error: 'E-mail et code requis.' });

  const user  = db.get('users').find(u => u.email === email && !u.deleted_at).value();
  if (!user)  return res.status(400).json({ error: 'Code invalide ou expiré.' });

  const reset = db.get('password_resets').find(r =>
    r.user_id === user.id && !r.used && new Date(r.expires_at) > new Date()
  ).value();
  if (!reset) return res.status(400).json({ error: 'Code invalide ou expiré (15 min max).' });

  const valid = await bcrypt.compare(String(otp), reset.otp_hash);
  if (!valid) return res.status(400).json({ error: 'Code incorrect. Vérifiez et réessayez.' });

  db.get('password_resets').find({ id: reset.id }).assign({ used: true }).write();
  const resetJwt = jwt.sign({ sub: user.id, type: 'reset' }, JWT_SECRET, { expiresIn: '10m' });
  res.json({ message: 'Code vérifié.', reset_token: resetJwt });
});

// ─── POST /api/auth/reset-password ───────────────────────────────────────────
router.post('/reset-password', async (req, res) => {
  const { reset_token, new_password } = req.body;

  if (!reset_token || !new_password)
    return res.status(400).json({ error: 'Paramètres manquants.' });
  if (typeof new_password !== 'string' || new_password.length < 8)
    return res.status(400).json({ error: 'Mot de passe : 8 caractères minimum.' });

  try {
    const decoded = jwt.verify(reset_token, JWT_SECRET);
    if (decoded.type !== 'reset') throw new Error('Wrong type');

    const hash = await bcrypt.hash(new_password, BCRYPT_ROUNDS);
    db.get('users').find({ id: decoded.sub }).assign({
      password_hash: hash, failed_attempts: 0, locked_until: null,
      updated_at: new Date().toISOString()
    }).write();
    audit(decoded.sub, 'RESET_PW_OK', req.ip, true);
    res.json({ message: 'Mot de passe réinitialisé avec succès.' });
  } catch (e) {
    res.status(400).json({ error: 'Lien de réinitialisation invalide ou expiré.' });
  }
});

// ─── POST /api/auth/oauth ─────────────────────────────────────────────────────
router.post('/oauth', async (req, res) => {
  try {
    const { provider, first_name, last_name } = req.body;
    const email = (req.body.email || '').toLowerCase().trim();
    const ip    = req.ip || '127.0.0.1';
    const ua    = req.headers['user-agent'] || '';

    if (!provider || !email)
      return res.status(400).json({ error: 'Provider et e-mail requis.' });
    if (!isValidEmail(email))
      return res.status(400).json({ error: 'E-mail OAuth invalide.' });

    const now = new Date().toISOString();
    let user  = db.get('users').find(u => u.email === email && !u.deleted_at).value();

    if (!user) {
      const initials = ((first_name || 'U')[0] + (last_name || 'S')[0]).toUpperCase();
      user = {
        id: uuidv4(), email, password_hash: null,
        first_name: first_name || 'Utilisateur', last_name: last_name || 'FormaPro',
        avatar_initials: initials, phone: '', siret: '', tva_number: '',
        tva_exempt: true, address: '', city: '', postal_code: '', country: 'FR',
        plan: 'starter', role: 'formateur', oauth_provider: provider,
        email_verified: true, is_active: true, deleted_at: null,
        rgpd_consent: true, rgpd_consent_date: now, rgpd_consent_ip: ip,
        marketing_consent: false,
        failed_attempts: 0, locked_until: null,
        last_login: now, login_count: 1, created_at: now, updated_at: now
      };
      db.get('users').push(user).write();
      db.get('settings').push({
        user_id: user.id, invoice_prefix: 'FP', default_payment_terms: 30,
        bank_iban: '', bank_bic: '',
        notif_invoice_reminder: true, notif_session_reminder: true, notif_email: true,
        created_at: now, updated_at: now
      }).write();
      consentLog(user.id, 'OAUTH_CONSENT', `Via ${provider}`, ip, ua);
    } else {
      if (!user.is_active)
        return res.status(403).json({ error: 'Compte désactivé.' });
      db.get('users').find({ id: user.id }).assign({
        last_login: now, login_count: (user.login_count || 0) + 1, updated_at: now
      }).write();
      user = db.get('users').find({ id: user.id }).value();
    }

    audit(user.id, `OAUTH_${provider.toUpperCase()}`, ip, true);
    const { access, refresh } = makeTokens(user);
    setCookies(res, access, refresh);
    res.json({ message: `Connexion ${provider} réussie.`, access_token: access, user: safeUser(user) });
  } catch (err) {
    console.error('[OAUTH]', err);
    res.status(500).json({ error: 'Erreur OAuth.' });
  }
});

// ─── GET /api/auth/export-data — RGPD Art. 20 ────────────────────────────────
router.get('/export-data', (req, res) => {
  const token = getToken(req);
  if (!token) return res.status(401).json({ error: 'Non authentifié.' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const uid     = decoded.sub;
    const user    = db.get('users').find({ id: uid }).value();
    if (!user)    return res.status(404).json({ error: 'Introuvable.' });

    const { password_hash, mfa_secret, ...safeU } = user;
    const data = {
      export_date:  new Date().toISOString(),
      rgpd_notice:  'Export RGPD — Article 20 — Droit à la portabilité des données',
      user:         safeU,
      clients:      db.get('clients').filter({ user_id: uid }).value(),
      sessions:     db.get('sessions').filter({ user_id: uid }).value(),
      invoices:     db.get('invoices').filter({ user_id: uid }).value(),
      qualiopi:     db.get('qualiopi').filter({ user_id: uid }).value(),
      consent_log:  db.get('consent_log').filter({ user_id: uid }).value()
    };

    consentLog(uid, 'DATA_EXPORT_RGPD', 'Export Art. 20', req.ip, req.headers['user-agent']);
    res.setHeader('Content-Disposition', `attachment; filename="formapro-donnees-${Date.now()}.json"`);
    res.setHeader('Content-Type', 'application/json');
    res.json(data);
  } catch (e) {
    res.status(401).json({ error: 'Token invalide.' });
  }
});

// ─── DELETE /api/auth/account — RGPD Art. 17 ─────────────────────────────────
router.delete('/account', (req, res) => {
  const token = getToken(req);
  if (!token) return res.status(401).json({ error: 'Non authentifié.' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const uid     = decoded.sub;
    const user    = db.get('users').find({ id: uid }).value();
    if (!user)    return res.status(404).json({ error: 'Introuvable.' });

    const now = new Date().toISOString();
    // Anonymise (conservation légale obligations comptables 10 ans) 
    db.get('users').find({ id: uid }).assign({
      email:         `deleted-${uid.substring(0, 8)}@supprime.formapro.fr`,
      password_hash: null,
      first_name:    '[Supprimé]',
      last_name:     '[RGPD Art.17]',
      phone: '', siret: '', address: '', city: '', postal_code: '',
      is_active:   false,
      deleted_at:  now,
      updated_at:  now
    }).write();

    consentLog(uid, 'ACCOUNT_DELETION_RGPD', 'Suppression Art. 17 — anonymisation', req.ip, req.headers['user-agent']);
    audit(uid, 'ACCOUNT_DELETED', req.ip, true);
    clearCookies(res);
    res.json({ message: 'Compte supprimé. Données personnelles anonymisées (RGPD Art. 17).' });
  } catch (e) {
    res.status(401).json({ error: 'Token invalide.' });
  }
});

module.exports = router;
